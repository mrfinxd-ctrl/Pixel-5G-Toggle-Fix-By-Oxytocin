file_path="/data/user_de/0/com.android.phone/files/"
insert_string=\
"<!--Pixel_5G_Toggle_Fix_By_Oxytocin_Start-->\n"\
"<boolean name=\"carrier_ut_provisioning_required_bool\" value=\"false\"/>\n"\
"<boolean name=\"carrier_supports_ss_over_ut_bool\" value=\"true\"/>\n"\
"<boolean name=\"carrier_volte_available_bool\" value=\"true\" />\n"\
"<boolean name=\"carrier_vt_available_bool\" value=\"true\" />\n"\
"<boolean name=\"carrier_wfc_ims_available_bool\" value=\"true\" />\n"\
"<boolean name=\"carrier_wfc_supports_wifi_only_bool\" value=\"true\" />\n"\
"<boolean name=\"editable_enhanced_4g_lte_bool\" value=\"true\" />\n"\
"<boolean name=\"enhanced_4g_lte_on_by_default_bool\" value=\"true\" />\n"\
"<boolean name=\"editable_wfc_mode_bool\" value=\"true\" />\n"\
"<boolean name=\"editable_wfc_roaming_mode_bool\" value=\"true\" />\n"\
"<boolean name=\"hide_lte_plus_data_icon_bool\" value=\"false\" />\n"\
"<boolean name=\"show_4g_for_lte_data_icon_bool\" value=\"true\" />\n"\
"<boolean name=\"vonr_enabled_bool\" value=\"true\" />\n"\
"<boolean name=\"is_vonr_enabled_bool\" value=\"true\" />\n"\
"<boolean name=\"vonr_setting_visibility_bool\" value=\"true\" />\n"\
"<boolean name=\"hide_preferred_network_type_bool\" value=\"false\" />\n"\
"<boolean name=\"editable_preferred_network_type_bool\" value=\"true\" />\n"\
"<boolean name=\"config_nr_enabled_bool\" value=\"true\" />\n"\
"<boolean name=\"carrier_allow_is_roaming_network_type_bool\" value=\"true\" />\n"\
"<boolean name=\"world_phone_bool\" value=\"true\" />\n"\
"<!--Pixel_5G_Toggle_Fix_By_Oxytocin_End-->"
find $file_path -maxdepth 1 -type f -name "carrierconfig-com.google.android.carrier*.xml" ! -name "*nosim*" | while read -r file; do
  if grep -q '</bundle>' "$file"; then
      if grep -q 'Pixel_5G_Toggle_Fix_By_Oxytocin' "$file"; then
        echo "Replace with the latest config."
        sed -i "/<!--Pixel_5G_Toggle_Fix_By_Oxytocin_Start-->/,/<!--Pixel_5G_Toggle_Fix_By_Oxytocin_End-->/c\\$insert_string" $file
      else
        sed -i "/<\/bundle>/i $insert_string" $file
        echo "Inserted test string into $file."
      fi
  else
      echo "No </bundle> tag found in $file. Skipping."
  fi
done

echo "Hey Listen 🤠 Don't forget to jerk off my boy😂"
echo "________________________________"
echo "________________________________"
echo "________________________________"
echo "________________________________"
echo "Procedure complete."