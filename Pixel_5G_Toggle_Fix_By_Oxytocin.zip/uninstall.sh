file_path="/data/user_de/0/com.android.phone/files/"
find $file_path -maxdepth 1 -type f -name "carrierconfig-com.google.android.carrier*.xml" ! -name "*nosim*" | while read -r file; do
  if grep -q '</bundle>' "$file"; then
      sed -i '/<!--Pixel_5G_Toggle_Fix_By_Oxytocin_Start-->/,/<!--Pixel_5G_Toggle_Fix_By_Oxytocin_End-->/d' "$file"
      echo "Deleted config items in $file"
  else
    echo "No </bundle> tag found in $file. Skipping."
  fi
done
